(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const views = ["dashboard", "vault", "privacy", "settings"];
  const titles = {dashboard:"Dashboard", vault:"Secure Vault", privacy:"Privatsphäre", settings:"Einstellungen"};
  let selectedFile = null;
  let decryptFile = null;
  let toastTimer = null;

  function showToast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 3400);
  }
  function go(view) {
    if (!views.includes(view)) return;
    views.forEach(v => $("view-" + v).classList.toggle("active", v === view));
    document.querySelectorAll("[data-view]").forEach(el => el.classList.toggle("active", el.dataset.view === view));
    $("page-name").textContent = titles[view];
    window.scrollTo({top:0, behavior:"smooth"});
  }
  document.querySelectorAll("[data-view]").forEach(el => el.addEventListener("click", () => go(el.dataset.view)));
  document.querySelectorAll("[data-go]").forEach(el => el.addEventListener("click", () => go(el.dataset.go)));

  const fileInput = $("file-input");
  const dropzone = $("dropzone");
  fileInput.addEventListener("change", () => setSelectedFile(fileInput.files && fileInput.files[0]));
  function setSelectedFile(file) {
    selectedFile = file || null;
    $("file-prompt").textContent = file ? file.name : "Datei auswählen oder hier ablegen";
    $("file-meta").textContent = file ? `${formatBytes(file.size)} · bereit zur Verschlüsselung` : "Datei bleibt bis zur Verschlüsselung in deinem Browser.";
    dropzone.classList.toggle("has-file", !!file);
  }
  ["dragenter","dragover"].forEach(evt => dropzone.addEventListener(evt, e => {e.preventDefault();dropzone.classList.add("dragover");}));
  ["dragleave","drop"].forEach(evt => dropzone.addEventListener(evt, e => {e.preventDefault();dropzone.classList.remove("dragover");}));
  dropzone.addEventListener("drop", e => {const f=e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];if(f)setSelectedFile(f);});

  $("decrypt-input").addEventListener("change", e => {
    decryptFile = e.target.files && e.target.files[0] || null;
    $("decrypt-meta").textContent = decryptFile ? `${decryptFile.name} · ${formatBytes(decryptFile.size)}` : "Noch keine Datei ausgewählt.";
  });

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    const units = ["KB","MB","GB","TB"];
    let n = bytes / 1024, i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return `${n.toLocaleString("de-DE",{maximumFractionDigits:1})} ${units[i]}`;
  }
  function showError(id, msg) { $(id).textContent = msg || ""; }
  function setBusy(busy) {
    $("progress-wrap").classList.toggle("show", busy);
    $("encrypt-btn").disabled = busy;
    $("decrypt-btn").disabled = busy;
  }
  function bytesToBase64(bytes) {
    let binary = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    return btoa(binary);
  }
  function base64ToBytes(str) {
    const binary = atob(str);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
  async function deriveKey(password, salt) {
    const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({name:"PBKDF2", salt, iterations:600000, hash:"SHA-256"}, material, {name:"AES-GCM", length:256}, false, ["encrypt","decrypt"]);
  }
  function downloadBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name; a.style.display = "none";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  function safeName(name) {
    return name.replace(/[\\/:*?"<>|]/g, "_").replace(/[\u0000-\u001f]/g, "_").slice(0,180) || "datei";
  }

  $("encrypt-btn").addEventListener("click", async () => {
    showError("form-error", "");
    if (!window.crypto || !crypto.subtle) return showError("form-error", "Dein Browser unterstützt die nötige Web-Crypto-API nicht. Öffne die Datei mit einem aktuellen Browser.");
    const password = $("password").value;
    const confirm = $("password-confirm").value;
    if (!selectedFile) return showError("form-error", "Bitte wähle zuerst eine Datei aus.");
    if (password.length < 12) return showError("form-error", "Bitte verwende ein Passwort mit mindestens 12 Zeichen.");
    if (password !== confirm) return showError("form-error", "Die beiden Passwörter stimmen nicht überein.");
    // Avoid accidentally freezing the browser with very large files in this early prototype.
    if (selectedFile.size > 100 * 1024 * 1024) return showError("form-error", "Für diesen Prototyp sind Dateien bis 100 MB vorgesehen.");
    setBusy(true);
    try {
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const key = await deriveKey(password, salt);
      const plain = await selectedFile.arrayBuffer();
      const encrypted = await crypto.subtle.encrypt({name:"AES-GCM", iv}, key, plain);
      const header = {
        format:"VELTRIX_V1",
        name:safeName(selectedFile.name),
        type:selectedFile.type || "application/octet-stream",
        created:new Date().toISOString(),
        kdf:"PBKDF2-SHA-256",
        iterations:600000,
        cipher:"AES-256-GCM",
        salt:bytesToBase64(salt),
        iv:bytesToBase64(iv)
      };
      const headerBytes = new TextEncoder().encode(JSON.stringify(header));
      const out = new Uint8Array(8 + headerBytes.length + encrypted.byteLength);
      out.set(new TextEncoder().encode("VLTX"), 0);
      new DataView(out.buffer).setUint32(4, headerBytes.length, false);
      out.set(headerBytes, 8);
      out.set(new Uint8Array(encrypted), 8 + headerBytes.length);
      downloadBlob(new Blob([out], {type:"application/octet-stream"}), safeName(selectedFile.name) + ".vltx");
      $("progress-text").textContent = "Verschlüsselung abgeschlossen.";
      showToast("Verschlüsselte Datei wurde zum Download bereitgestellt.");
      $("password").value = ""; $("password-confirm").value = "";
    } catch (err) {
      console.error(err);
      showError("form-error", "Verschlüsselung fehlgeschlagen. Bitte versuche es mit einer kleineren Testdatei und einem aktuellen Browser.");
    } finally {
      setBusy(false);
      setTimeout(() => $("progress-wrap").classList.remove("show"), 1500);
    }
  });

  $("decrypt-btn").addEventListener("click", async () => {
    showError("decrypt-error", "");
    if (!window.crypto || !crypto.subtle) return showError("decrypt-error", "Dieser Browser unterstützt die nötige Web-Crypto-API nicht.");
    const password = $("decrypt-password").value;
    if (!decryptFile) return showError("decrypt-error", "Bitte wähle zuerst eine .vltx-Datei aus.");
    if (!password) return showError("decrypt-error", "Bitte gib das Passwort ein.");
    if (decryptFile.size > 110 * 1024 * 1024) return showError("decrypt-error", "Diese Datei ist für den frühen Prototyp zu groß.");
    setBusy(true);
    try {
      const data = new Uint8Array(await decryptFile.arrayBuffer());
      if (data.length < 8 || new TextDecoder().decode(data.slice(0,4)) !== "VLTX") throw new Error("Ungültiges Dateiformat");
      const headerLength = new DataView(data.buffer, data.byteOffset, data.byteLength).getUint32(4, false);
      if (headerLength < 2 || headerLength > 20000 || 8 + headerLength >= data.length) throw new Error("Ungültiger Dateiheader");
      const header = JSON.parse(new TextDecoder().decode(data.slice(8, 8 + headerLength)));
      if (header.format !== "VELTRIX_V1" || header.iterations !== 600000 || header.cipher !== "AES-256-GCM") throw new Error("Nicht unterstütztes Veltrix-Dateiformat");
      const salt = base64ToBytes(header.salt), iv = base64ToBytes(header.iv);
      const key = await deriveKey(password, salt);
      const encrypted = data.slice(8 + headerLength);
      const plain = await crypto.subtle.decrypt({name:"AES-GCM", iv}, key, encrypted);
      downloadBlob(new Blob([plain], {type:header.type || "application/octet-stream"}), safeName(header.name || "entschluesselte-datei"));
      $("decrypt-password").value = "";
      showToast("Datei entschlüsselt und zum Download bereitgestellt.");
    } catch (err) {
      console.error(err);
      showError("decrypt-error", "Entschlüsselung fehlgeschlagen. Prüfe das Passwort und ob die Datei unverändert ist.");
    } finally { setBusy(false); }
  });

  // Helpful compatibility message for contexts that block local file crypto.
  if (!window.crypto || !crypto.subtle) {
    showToast("Hinweis: Öffne Veltrix mit einem aktuellen Browser, der Web Crypto unterstützt.");
  }
})();