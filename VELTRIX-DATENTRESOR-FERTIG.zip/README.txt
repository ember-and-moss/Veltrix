VELTRIX — DATENTRESOR + SEPARATER ENTSCHLÜSSLER

Dateien für GitHub Pages:
- index.html: VELTRIX-Website inklusive Download-Link zum Entschlüssler
- styles.css: bestehendes Design
- app.js: Verschlüsseln/Entschlüsseln im Browser (AES-256-GCM, PBKDF2-SHA-256, 600.000 Iterationen)
- veltrix-entschluessler.html: separat nutzbarer Entschlüssler für VELTRIX-V1-.vltx-Dateien

VERÖFFENTLICHEN
Lade alle fünf Dateien in das Hauptverzeichnis des GitHub-Repositorys hoch. Ersetze gleichnamige Dateien und klicke auf Commit changes. GitHub Pages muss auf Branch main und Ordner /(root) eingestellt sein.

WICHTIG
Die Verschlüsselung erfolgt im Browser. Vergisst du das Passwort, kann die Datei nicht wiederhergestellt werden. Teste zuerst mit einer Kopie. Bewahre Originaldateien auf. Dies ist ein Prototyp und kein unabhängig geprüfter Sicherheitsstandard. Der Entschlüssler unterstützt das VLTX / VELTRIX_V1-Format dieser Version.
