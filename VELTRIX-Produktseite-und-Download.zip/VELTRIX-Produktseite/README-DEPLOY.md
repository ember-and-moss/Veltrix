# VELTRIX product page + download

## What is included
- `index.html` — simple product/landing page with a download button.
- `VELTRIX-Local.zip` — the downloadable app bundle.
- `VELTRIX-Local/` — the same app files unpacked for inspection/editing.

## Publish on GitHub Pages
1. Extract this package on your computer.
2. Upload the **contents** of this folder to the root of the GitHub repository used for the product page: `index.html`, `VELTRIX-Local.zip`, and optionally `VELTRIX-Local/` and this README.
3. Commit the changes and wait for GitHub Pages to publish.
4. Open the published site and click “VELTRIX herunterladen”. Check that the browser downloads `VELTRIX-Local.zip` rather than navigating into it.

The product-page root `index.html` is intentionally separate from the app's own `VELTRIX-Local/index.html` to avoid filename collisions.

## Prototype/security note
This bundle is a prototype, not independently audited security software. Test only with unimportant copies. Do not advertise it as audited, fully anonymous, or guaranteed secure.
