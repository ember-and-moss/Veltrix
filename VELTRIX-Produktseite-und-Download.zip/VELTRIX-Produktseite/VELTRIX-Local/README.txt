VELTRIX — LOCAL WORKSPACE

START:
1. ZIP entpacken.
2. Den Ordner VELTRIX-Local öffnen.
3. index.html doppelklicken.
4. Die Oberfläche läuft lokal im Browser. Kein Hosting und kein Webserver nötig.

WICHTIG:
Diese Version öffnet sich in deinem Standardbrowser, nicht in einem eigenen Programmfenster. Für ein eigenständiges Fenster braucht es eine Desktop-App, die separat gebaut werden muss.

Der Dateitresor ist ein nicht auditierter Prototyp. Er verschlüsselt einzelne Dateien als .vltx mit AES-GCM/PBKDF2, löscht das Original nicht und unterstützt bis zu 100 MB. Dateiname/Metadaten sind nicht verschlüsselt. Erst mit unwichtigen Testdateien testen. Passwortverlust bedeutet Datenverlust.

Die lokale Oberfläche lädt keine externen Skripte oder Schriftarten. Das ist keine Garantie für Spurenfreiheit: Windows, Browser, Backups oder Sicherheitssoftware können Aktivitäten protokollieren.

Tor Browser ist nicht enthalten. Offizielle Quelle: https://www.torproject.org/download/
