VELTRIX — Local Workspace

GITHUB PAGES
1. Entpacke diese ZIP-Datei.
2. Lade index.html, style.css, app.js und README.txt in das Stammverzeichnis deines GitHub-Repositorys hoch.
3. Wenn GitHub fragt, bestätige das Ersetzen vorhandener index.html/style.css-Dateien.
4. Commit changes. GitHub Pages veröffentlicht die Änderungen automatisch.

DATENTRESOR
- Verschlüsselt Dateien lokal im Browser; die Dateiinhalte werden nicht an einen VELTRIX-Server hochgeladen.
- Neue Dateien verwenden AES-256-GCM mit PBKDF2-HMAC-SHA-256 (600.000 Iterationen), zufälligem Salt und IV.
- Metadaten im neuen VELTRIX2-Format werden authentifiziert. Ältere VELTRIX1-Dateien können weiterhin entschlüsselt werden.
- Maximal 100 MB pro Datei. Verwende ein einzigartiges Passwort mit mindestens 12 Zeichen.
- Bei vergessenem Passwort gibt es keine Wiederherstellung. Bewahre Originale und Sicherungskopien auf.
- Vor wichtigen Dokumenten mit unwichtigen Testdateien testen. Dieses Projekt wurde nicht unabhängig sicherheitsauditiert und ist keine Garantie für professionelle Datensicherheit.
