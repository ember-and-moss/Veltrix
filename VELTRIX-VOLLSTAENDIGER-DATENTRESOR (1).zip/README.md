# VELTRIX – vollständiger Dateitresor

Diese ZIP enthält die Dateien für das Stammverzeichnis deiner GitHub-Pages-Website. Die bestehende VELTRIX-Oberfläche bleibt erhalten; der integrierte Dateitresor ist über die linke Navigation **Dateitresor** erreichbar.

## Dateien im ZIP
- `index.html` – Website inklusive integriertem Dateitresor und Download-Link zum separaten Entschlüssler
- `style.css` – Design
- `app.js` – Verschlüsseln und Entschlüsseln im Browser
- `veltrix-entschluessler.html` – separat herunterladbares Entschlüsselungswerkzeug

## Veröffentlichen
Lade diese vier Dateien (und optional diese README) direkt ins Stammverzeichnis des bestehenden GitHub-Repositorys hoch und bestätige das Ersetzen der gleichnamigen Dateien. Danach die Änderungen committen und die Website mit `Strg + F5` neu laden.

## Sicherheitshinweise
- Verschlüsselung: AES-256-GCM mit PBKDF2-HMAC-SHA-256 (600.000 Iterationen) und zufälligem Salt/IV.
- Neue Dateien verwenden das Format VELTRIX2, bei dem auch die Metadaten authentifiziert werden. Der Entschlüssler unterstützt VELTRIX1 und VELTRIX2.
- Maximal 100 MB pro Datei. Passwort mindestens 12 Zeichen; ein langes, einzigartiges Passwort ist besser.
- Passwortverlust kann nicht rückgängig gemacht werden. Originale und Backups aufbewahren und zuerst mit Testdateien arbeiten.
- Das Projekt ist ein Prototyp und wurde nicht unabhängig sicherheitsauditiert. Nicht als einzige Schutzmaßnahme für hochsensible Dateien verwenden.
